<?php

// BASE URL
define('__BASEURL__','http://'. $_SERVER['HTTP_HOST'].'');//dont append slash
