<?php 

include "./config/config.php";
include "./lang/lang.php";
include "./lang/functions.php";
$lang = getLang();
$tr = tr('./lang');
require "./head.php";

$Raw_Json = file_get_contents("./main.json");

$data = json_decode($Raw_Json,true);


?>
<script>
  function setLanguage(lang) {
    document.cookie = "lang="+lang+";path=/";
    location.reload();
  }
</script>
    <!--    Main Content-->
      <section id="labs">
        <section id="labs">
        <div class="container">
          <h1 class="display-6 fw-semi-bold"> Vulns</h1>
          <p class="fs-2">Choose your vulnerability and start to learn.</p>
            <div class="col-md-6 mb-4">
              <a href="/lab/sql-injection" class="text-decoration-none text-muted">
              <div class=" border rounded-1 border-700 h-100 features-items">
                <div class="p-5">
                <img src="public/assets/img/vulns/sqli.png" alt="Dashboard" style="width:48px;height:48px;" />
                  <h3 class="pt-3 lh-base" >SQL Injection                  <span class="badge bg-secondary">5 lab</span>
                  </h3>
                  <p class="mb-0">It is an attack technique used to attack database-based applications; where the attacker takes advantage of SQL language features and adds new SQL statements to the corresponding field on the standard application screen.</p>
                </div>
              </div>
            </a>
            </div>
                        <div class="col-md-6 mb-4">
              <a href="/lab/insecure-deserialization" class="text-decoration-none text-muted">
              <div class=" border rounded-1 border-700 h-100 features-items">
                <div class="p-5">
                <img src="public/assets/img/vulns/insecure.png" alt="Dashboard" style="width:48px;height:48px;" />
                  <h3 class="pt-3 lh-base" >Insecure Deserialization                  <span class="badge bg-secondary">5 lab</span>
                  </h3>
                  <p class="mb-0">Insecure deserialization is a vulnerability which occurs when user-controllable untrusted data is deserialized by a website without sanitize.Vulnerability cause to gain priviliges may even remote code execution.</p>
                </div>
              </div>
            </a>
            </div>
                        <div class="col-md-6 mb-4">
              <a href="/lab/broken-authentication" class="text-decoration-none text-muted">
              <div class=" border rounded-1 border-700 h-100 features-items">
                <div class="p-5">
                <img src="public/assets/img/vulns/broken.png" alt="Dashboard" style="width:48px;height:48px;" />
                  <h3 class="pt-3 lh-base" >Broken Authentication                  <span class="badge bg-secondary">3 lab</span>
                  </h3>
                  <p class="mb-0">Broken authentication refers to the vulnerabilities or weaknesses inherent in an online platform or application that allows hackers to bypass the login security and gain access to all the privileges owned by the hacked user.</p>
                </div>
              </div>
            </a>
            </div>
              
        </div>
        <!-- end of .container-->
      </section>
      <!-- <section> close ============================-->
      <!-- <section> begin ============================-->
        <section>

          <div class="container">
            <div class="py-md-3">
              <hr class="mt-1 text-1000" />
            </div>

            <div class="row mx-md-5 px-md-5 d-flex justify-content-evenly">
                  <div class="col-6 col-lg-auto mt-5 mt-lg-0"><img src="public/assets/img/gallery/brands/sibervatangray.png" alt="Yavuzlar" style="height:35px;" /></div>
                  <div class="col-4 col-lg-auto mt-5 mt-lg-0"><img src="public/assets/img/gallery/brands/cyropslogo.png" alt="Cyrops" style="height:35px;" /></div>
                  <div class="col-6 col-lg-auto mt-5 mt-lg-0"><img src="public/assets/img/gallery/brands/yavuzlargray.png" alt="Siber Vatan" style="height:35px;" /></div>
             </div>
          </div>
          <!-- end of .container-->
        </section>
        <!-- <section> close ============================-->
        <!-- ============================================-->
<?php
  require "./footer.php";
?>
